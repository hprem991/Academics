
package studentRecordsBackup.bst;
import studentRecordsBackup.bst.FilterI;

public class OddFilter implements FilterI {
	@Override
	public boolean filter(int UPDATE_VALUE){
		if(0 != (UPDATE_VALUE % 2)) 
			return true;
		return false;
	}
	
	@Override
	public String toString(){
		return "";
	}
}
