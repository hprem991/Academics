

package studentRecordsBackup.bst;

public interface FilterI {
	   public boolean filter(int UPDATE_VALUE); // Filter Type
}
