
package studentRecordsBackup.util;
import studentRecordsBackup.bst.BST;



public interface BSTWorkshopInterface {
	
	public void construct(BST tree,BST backup_1,BST backup_2);
	
}
