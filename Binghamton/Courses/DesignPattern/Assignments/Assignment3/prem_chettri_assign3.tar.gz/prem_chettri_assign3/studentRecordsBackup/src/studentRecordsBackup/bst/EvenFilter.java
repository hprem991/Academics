
package studentRecordsBackup.bst;

import studentRecordsBackup.bst.FilterI;

public class EvenFilter implements FilterI {
	public boolean filter(int UPDATE_VALUE){
		if(0 == (UPDATE_VALUE % 2)) 
			return true;
		return false;
	}
	
	/********************************************************
	 * 
	 * METHOD NAME : toString
	 * INPUT 	   : void
	 * RETURNS	   : String
	 * PURPOSE     : Stringify the data members
	 *
	 ********************************************************/
	
	@Override
	public String toString(){
		return "";
	}
}
