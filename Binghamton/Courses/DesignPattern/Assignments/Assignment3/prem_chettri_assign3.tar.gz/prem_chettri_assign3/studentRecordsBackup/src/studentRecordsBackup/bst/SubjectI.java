
package studentRecordsBackup.bst;

public interface SubjectI {
	public void listen(int  UPDATE_VALUE);
}
