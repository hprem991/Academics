package genericCheckpointing.src.genericCheckpointing.server;

public interface StoreRestoreI {

}
