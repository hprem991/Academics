package genericCheckpointing.src.genericCheckpointing.util;

public class SerializableObject {

}
