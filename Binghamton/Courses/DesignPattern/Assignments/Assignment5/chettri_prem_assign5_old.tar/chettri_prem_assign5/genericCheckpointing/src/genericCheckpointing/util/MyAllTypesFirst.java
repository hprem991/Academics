package genericCheckpointing.src.genericCheckpointing.util;

public class MyAllTypesFirst extends SerializableObject {

	private int myInt;
	private long myLong;
	private String myString;
	private boolean myBool;
	
	public MyAllTypesFirst() {
		// Default Constructor
	}
	
	public MyAllTypesFirst(int count) {
		// TODO Auto-generated constructor stub
		myInt = (int) (Math.random() * count);
		myLong = (long) Math.random();
		myString = ""+Math.random();
		myBool = Math.random() > 0.5 ? true :false;
	}
	
	
	public int getMyInt() {
		return myInt;
	}
	
	public void setMyInt(int myInt) {
		this.myInt = myInt;
	}
	
	public long getMyLong() {
		return myLong;
	}
	
	public void setMyLong(long myLong) {
		this.myLong = myLong;
	}
	
	
	public String getMyString() {
		return myString;
	}
	
	public void setMyString(String myString) {
		this.myString = myString;
	}
	
	public boolean getMyBool() {
		return myBool;
	}
	
	public void setMyBool(boolean myBool) {
		this.myBool = myBool;
	}
	
	@Override
	public String toString(){
		return "INT "+myInt+" LONG "+myLong+" STRING "+myString+" BOOL "+myBool;
	}
	
	@Override
	public boolean equals(Object obj){
		if(obj instanceof MyAllTypesFirst){
			return ((this.getMyInt() == ((MyAllTypesFirst) obj).getMyInt()) ? 
					((this.getMyString().equals(((MyAllTypesFirst) obj).getMyString())) ? 
					((this.getMyLong() == ((MyAllTypesFirst) obj).getMyLong())?
					(this.getMyBool() == ((MyAllTypesFirst) obj).getMyBool())
					:false ): false) : false);
		}
		return false;
	}
}
