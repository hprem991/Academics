
package primeThreads.store;

public interface StdoutDisplayInterface {
    public void writeSumToScreen();
} 
